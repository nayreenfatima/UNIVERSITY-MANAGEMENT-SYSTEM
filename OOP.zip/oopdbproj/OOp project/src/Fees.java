
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Fees extends javax.swing.JFrame {

    public Fees() {
        initComponents();
        display();
    }
    
    public void reset(){
        
        StdID.setText("");
        StdName.setText("");
        Amount.setText("");
        DeptID.setText("");
        Sem.setText("");
     
    }
    
    public void display(){
        
        try{
        
            Connection SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            Statement stmt = SC1.createStatement();
            String query = "SELECT * FROM Fees";
            ResultSet rs = stmt.executeQuery(query);
            DefaultTableModel tblModel = (DefaultTableModel)Fees_Table.getModel();
            tblModel.setRowCount(0);
            
            while(rs.next()){
                
                String sID = rs.getString(1);
                String sName = rs.getString(2);
                String amount = rs.getString(3);
                String sDeptID = rs.getString(4);
                String sSem = rs.getString(5);
                
                String[] rows = {sID, sName, amount , sDeptID, sSem};
                
                tblModel.addRow(rows);
                
            }
    
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
    } 


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        DeptIntakeLb = new javax.swing.JLabel();
        StdID = new javax.swing.JTextField();
        StdName = new javax.swing.JTextField();
        DeptNameLb = new javax.swing.JLabel();
        PayBtn = new javax.swing.JButton();
        ResetBtn = new javax.swing.JButton();
        DeptIntakeLb1 = new javax.swing.JLabel();
        DeptID = new javax.swing.JTextField();
        Sem = new javax.swing.JTextField();
        DeptIntakeLb2 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        Departments1 = new javax.swing.JButton();
        Fees1 = new javax.swing.JButton();
        Salary1 = new javax.swing.JButton();
        Faculty1 = new javax.swing.JButton();
        Students1 = new javax.swing.JButton();
        Home1 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        Courses1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        logout1 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        ahs = new javax.swing.JLabel();
        Amount = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Fees_Table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel14.setFont(new java.awt.Font("Baskerville Old Face", 1, 30)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("LSCE STUDENT FEES");

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/University-of-london-logo_1.png"))); // NOI18N

        DeptIntakeLb.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptIntakeLb.setText("Student Name:");

        StdID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StdIDActionPerformed(evt);
            }
        });

        StdName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StdNameActionPerformed(evt);
            }
        });

        DeptNameLb.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptNameLb.setText("Student ID:");

        PayBtn.setText("Pay");
        PayBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PayBtnActionPerformed(evt);
            }
        });

        ResetBtn.setText("Reset");
        ResetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetBtnActionPerformed(evt);
            }
        });

        DeptIntakeLb1.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptIntakeLb1.setText("Semester:");

        DeptID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeptIDActionPerformed(evt);
            }
        });

        Sem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SemActionPerformed(evt);
            }
        });

        DeptIntakeLb2.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        DeptIntakeLb2.setText("Department ID:");

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/HOME.png"))); // NOI18N
        jLabel44.setText("jLabel3");

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-schoolboy-at-a-desk-32.png"))); // NOI18N
        jLabel45.setText("jLabel6");

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-student-center-30.png"))); // NOI18N
        jLabel46.setText("jLabel7");

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-department-50.png"))); // NOI18N
        jLabel47.setText("jLabel10");

        jButton12.setBorder(null);
        jButton12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton12.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-pay-30.png"))); // NOI18N
        jLabel48.setText("jLabel9");

        jLabel49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-teacher-50.png"))); // NOI18N
        jLabel49.setText("jLabel8");

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-cash-30.png"))); // NOI18N

        Departments1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Departments1.setText("Departments");
        Departments1.setBorderPainted(false);
        Departments1.setContentAreaFilled(false);
        Departments1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Departments1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Departments1Home4ActionPerformed(evt);
            }
        });

        Fees1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Fees1.setText("Fees");
        Fees1.setBorderPainted(false);
        Fees1.setContentAreaFilled(false);
        Fees1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Fees1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Fees1Home5ActionPerformed(evt);
            }
        });

        Salary1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Salary1.setText("Salary");
        Salary1.setBorderPainted(false);
        Salary1.setContentAreaFilled(false);
        Salary1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Salary1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salary1Home6ActionPerformed(evt);
            }
        });

        Faculty1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Faculty1.setText("Faculty");
        Faculty1.setBorderPainted(false);
        Faculty1.setContentAreaFilled(false);
        Faculty1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Faculty1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Faculty1Home7ActionPerformed(evt);
            }
        });

        Students1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Students1.setText("Students");
        Students1.setBorderPainted(false);
        Students1.setContentAreaFilled(false);
        Students1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Students1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Students1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Students1Home2ActionPerformed(evt);
            }
        });

        Home1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Home1.setText("Home");
        Home1.setBorderPainted(false);
        Home1.setContentAreaFilled(false);
        Home1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Home1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Home1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home1Home2ActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Courses1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Courses1.setText("Courses");
        Courses1.setBorderPainted(false);
        Courses1.setContentAreaFilled(false);
        Courses1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Courses1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Courses1Home2ActionPerformed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-logout-rounded-down-50.png"))); // NOI18N
        jLabel6.setText("jLabel5");

        logout1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        logout1.setForeground(new java.awt.Color(204, 0, 0));
        logout1.setText("Logout");
        logout1.setBorderPainted(false);
        logout1.setContentAreaFilled(false);
        logout1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout1Home2ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton12)
                .addGap(891, 891, 891))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logout1))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Courses1)
                                    .addComponent(Students1)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Home1))))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel49, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel50, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Faculty1)
                            .addComponent(Fees1)
                            .addComponent(Salary1)
                            .addComponent(Departments1))))
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(751, 751, 751))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel44)
                                    .addComponent(Home1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Students1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Courses1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(27, 27, 27)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Departments1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel48)
                                    .addComponent(Fees1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Faculty1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel50)
                                    .addComponent(Salary1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(logout1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(29, 29, 29)
                .addComponent(jButton12)
                .addContainerGap())
        );

        ahs.setFont(new java.awt.Font("Times New Roman", 1, 15)); // NOI18N
        ahs.setText("Amount:");

        Amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AmountActionPerformed(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        Fees_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CourseID", "CourseName", "Amount", "DeptID", "Semester"
            }
        ));
        jScrollPane1.setViewportView(Fees_Table);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 716, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel2)
                        .addGap(35, 35, 35)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DeptNameLb, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(StdID, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DeptIntakeLb, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(StdName, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(60, 60, 60)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ahs, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Amount, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(PayBtn)
                                .addGap(157, 157, 157)
                                .addComponent(ResetBtn))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DeptIntakeLb2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DeptID, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(75, 75, 75)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DeptIntakeLb1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Sem, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(DeptIntakeLb, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(DeptNameLb, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ahs, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(StdID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(StdName, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(Amount, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DeptIntakeLb1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DeptIntakeLb2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DeptID, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Sem, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PayBtn)
                            .addComponent(ResetBtn))
                        .addGap(30, 30, 30)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void SemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SemActionPerformed
    }//GEN-LAST:event_SemActionPerformed

    private void DeptIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeptIDActionPerformed
    }//GEN-LAST:event_DeptIDActionPerformed

    private void ResetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetBtnActionPerformed
    
        reset();
    }//GEN-LAST:event_ResetBtnActionPerformed

    private void PayBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PayBtnActionPerformed
       
        if (StdID.getText().equals("") || StdName.getText().equals("")
                || Amount.getText().equals("") || DeptID.getText().equals("")|| 
                Sem.getText().equals("")){
            
            JOptionPane.showMessageDialog(null, "Missing Information.", "Error",
                    JOptionPane.OK_OPTION+ JOptionPane.ERROR_MESSAGE);
         }
         else {
            
            int sID = Integer.parseInt(StdID.getText().toString());
            String Name = StdName.getText().toString();
            String amount = Amount.getText().toString();
            int dID = Integer.parseInt(DeptID.getText().toString());
            int sem = Integer.parseInt(Sem.getText().toString());
            
            String query = "INSERT INTO Fees values ("+sID+",'"+Name+"',"+amount+", "+dID+","+sem+")" ;
            
            try {
               
            Connection SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            Statement stmt = SC1.createStatement();
            stmt.execute(query);
             JOptionPane.showMessageDialog(null, "Fees Paid."+ " "+
             JOptionPane.OK_OPTION + JOptionPane.INFORMATION_MESSAGE);
             display();
             reset();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
            
         }
        
    }//GEN-LAST:event_PayBtnActionPerformed

    private void StdNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StdNameActionPerformed
    }//GEN-LAST:event_StdNameActionPerformed

    private void StdIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StdIDActionPerformed
    }//GEN-LAST:event_StdIDActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

    }//GEN-LAST:event_jButton12ActionPerformed

    private void Departments1Home4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Departments1Home4ActionPerformed

        Departments d1 = new Departments();
        dispose();
        d1.setVisible(true);
    }//GEN-LAST:event_Departments1Home4ActionPerformed

    private void Fees1Home5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Fees1Home5ActionPerformed

        Fees f1 = new Fees();
        dispose();
        f1.setVisible(true);
    }//GEN-LAST:event_Fees1Home5ActionPerformed

    private void Salary1Home6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salary1Home6ActionPerformed

        Salaries sal1 = new Salaries();
        dispose();
        sal1.setVisible(true);
    }//GEN-LAST:event_Salary1Home6ActionPerformed

    private void Faculty1Home7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Faculty1Home7ActionPerformed

        Faculty fac1 = new Faculty();
        dispose();
        fac1.setVisible(true);
    }//GEN-LAST:event_Faculty1Home7ActionPerformed

    private void Students1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Students1Home2ActionPerformed

        Student s1 = new Student();
        dispose();
        s1.setVisible(true);
    }//GEN-LAST:event_Students1Home2ActionPerformed

    private void Home1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home1Home2ActionPerformed

        Home h1 = new Home();
        dispose();
        h1.setVisible(true);
    }//GEN-LAST:event_Home1Home2ActionPerformed

    private void Courses1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Courses1Home2ActionPerformed

        Course c1 = new Course();
        dispose();
        c1.setVisible(true);
    }//GEN-LAST:event_Courses1Home2ActionPerformed

    private void logout1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout1Home2ActionPerformed

        Login log = new Login();
        dispose();
        log.setVisible(true);
    }//GEN-LAST:event_logout1Home2ActionPerformed

    private void AmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AmountActionPerformed
    }//GEN-LAST:event_AmountActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Amount;
    private javax.swing.JButton Courses1;
    private javax.swing.JButton Departments1;
    private javax.swing.JTextField DeptID;
    private javax.swing.JLabel DeptIntakeLb;
    private javax.swing.JLabel DeptIntakeLb1;
    private javax.swing.JLabel DeptIntakeLb2;
    private javax.swing.JLabel DeptNameLb;
    private javax.swing.JButton Faculty1;
    private javax.swing.JButton Fees1;
    private javax.swing.JTable Fees_Table;
    private javax.swing.JButton Home1;
    private javax.swing.JButton PayBtn;
    private javax.swing.JButton ResetBtn;
    private javax.swing.JButton Salary1;
    private javax.swing.JTextField Sem;
    private javax.swing.JTextField StdID;
    private javax.swing.JTextField StdName;
    private javax.swing.JButton Students1;
    private javax.swing.JLabel ahs;
    private javax.swing.JButton jButton12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout1;
    // End of variables declaration//GEN-END:variables
}
