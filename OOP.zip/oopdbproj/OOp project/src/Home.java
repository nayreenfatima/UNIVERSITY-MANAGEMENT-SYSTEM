
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Home extends javax.swing.JFrame {
   
    public Home() {
        initComponents();
        countStudents();
        countFaculty();
        countDepartments();
        countFees();
        countSalaries();
    }
    
    private void countStudents(){
        
        Connection SC1;
        Statement stmt;
        ResultSet rs;
        
        try{
            
            SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            stmt = SC1.createStatement();
            String query = "Select Count(*) from Students";
            rs = stmt.executeQuery(query);

            if (rs.next()) {
            int count = rs.getInt(1);
            Std.setText(String.valueOf(count));
        }
    } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void countFaculty(){
        
        Connection SC1;
        Statement stmt;
        ResultSet rs;
        
        try{
            
            SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            stmt = SC1.createStatement();
            String query = "Select Count(*) from Faculty";
            rs = stmt.executeQuery(query);

            if (rs.next()) {
            int count = rs.getInt(1);
            Fac.setText(String.valueOf(count));
        }
    } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    private void countDepartments(){
        
        Connection SC1;
        Statement stmt;
        ResultSet rs;
        
        try{
            
            SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            stmt = SC1.createStatement();
            String query = "Select Count(*) from Departments";
            rs = stmt.executeQuery(query);

            if (rs.next()) {
            int count = rs.getInt(1);
            Dep.setText(String.valueOf(count));
        }
    } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    private void countFees(){
        
        Connection SC1;
        Statement stmt;
        ResultSet rs;
        
        try{
            
            SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            stmt = SC1.createStatement();
            String query = "Select Sum(Amount) from Fees";
            rs = stmt.executeQuery(query);

            if (rs.next()) {
            int sum = rs.getInt(1);
            Fin.setText("$" + String.valueOf(sum));
        }
    } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    private void countSalaries(){
        
        Connection SC1;
        Statement stmt;
        ResultSet rs;
        
        try{
            
            SC1 = DriverManager.getConnection( "jdbc:sqlserver://localhost\\DESKTOP-2SK42F8:1433;databaseName=UniversityManagementSystem;encrypt=true;trustServerCertificate=true;","User","123");
            stmt = SC1.createStatement();
            String query = "Select Sum(SalAmount) from Salary";
            rs = stmt.executeQuery(query);

            if (rs.next()) {
            int sum = rs.getInt(1);
            Sal.setText("$" + String.valueOf(sum));
        }
    } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jButton12 = new javax.swing.JButton();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        Departments1 = new javax.swing.JButton();
        Fees1 = new javax.swing.JButton();
        Salary1 = new javax.swing.JButton();
        Faculty1 = new javax.swing.JButton();
        Students1 = new javax.swing.JButton();
        Home1 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        Courses1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        logout1 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Std = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Dep = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Fac = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Fin = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Sal = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-department-50.png"))); // NOI18N
        jLabel10.setText("jLabel10");

        jPanel4.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Baskerville Old Face", 1, 34)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("LONDON SCHOOL OF COMPUTER ENGINEERING");
        jLabel1.setToolTipText("");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 19, 860, 48));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/University-of-london-logo_1.png"))); // NOI18N
        jLabel11.setText("jLabel11");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 56, 78));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 995, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 32, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 96, -1, -1));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/HOME.png"))); // NOI18N
        jLabel44.setText("jLabel3");

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-schoolboy-at-a-desk-32.png"))); // NOI18N
        jLabel45.setText("jLabel6");

        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-student-center-30.png"))); // NOI18N
        jLabel46.setText("jLabel7");

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-department-50.png"))); // NOI18N
        jLabel47.setText("jLabel10");

        jButton12.setBorder(null);
        jButton12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton12.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-pay-30.png"))); // NOI18N
        jLabel48.setText("jLabel9");

        jLabel49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-teacher-50.png"))); // NOI18N
        jLabel49.setText("jLabel8");

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-cash-30.png"))); // NOI18N

        Departments1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Departments1.setText("Departments");
        Departments1.setBorderPainted(false);
        Departments1.setContentAreaFilled(false);
        Departments1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Departments1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Departments1Home4ActionPerformed(evt);
            }
        });

        Fees1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Fees1.setText("Fees");
        Fees1.setBorderPainted(false);
        Fees1.setContentAreaFilled(false);
        Fees1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Fees1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Fees1Home5ActionPerformed(evt);
            }
        });

        Salary1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Salary1.setText("Salary");
        Salary1.setBorderPainted(false);
        Salary1.setContentAreaFilled(false);
        Salary1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Salary1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salary1Home6ActionPerformed(evt);
            }
        });

        Faculty1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Faculty1.setText("Faculty");
        Faculty1.setBorderPainted(false);
        Faculty1.setContentAreaFilled(false);
        Faculty1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Faculty1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Faculty1Home7ActionPerformed(evt);
            }
        });

        Students1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Students1.setText("Students");
        Students1.setBorderPainted(false);
        Students1.setContentAreaFilled(false);
        Students1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Students1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Students1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Students1Home2ActionPerformed(evt);
            }
        });

        Home1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Home1.setText("Home");
        Home1.setBorderPainted(false);
        Home1.setContentAreaFilled(false);
        Home1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Home1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        Home1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Home1Home2ActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Courses1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        Courses1.setText("Courses");
        Courses1.setBorderPainted(false);
        Courses1.setContentAreaFilled(false);
        Courses1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Courses1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Courses1Home2ActionPerformed(evt);
            }
        });

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-logout-rounded-down-50.png"))); // NOI18N
        jLabel6.setText("jLabel5");

        logout1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        logout1.setForeground(new java.awt.Color(204, 0, 0));
        logout1.setText("Logout");
        logout1.setBorderPainted(false);
        logout1.setContentAreaFilled(false);
        logout1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout1Home2ActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 9, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton12)
                .addGap(891, 891, 891))
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logout1))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Courses1)
                                    .addComponent(Students1)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Home1))))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel49, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel50, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Faculty1)
                            .addComponent(Fees1)
                            .addComponent(Salary1)
                            .addComponent(Departments1))))
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(751, 751, 751))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel44)
                                    .addComponent(Home1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Students1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Courses1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(25, 25, 25)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Departments1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel48)
                                    .addComponent(Fees1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Faculty1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel50)
                                    .addComponent(Salary1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(logout1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(29, 29, 29)
                .addComponent(jButton12)
                .addContainerGap())
        );

        jPanel2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 145, 200, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));

        jLabel2.setBackground(new java.awt.Color(0, 0, 102));
        jLabel2.setFont(new java.awt.Font("Calibri", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("STATISTICS");

        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-schoolboy-at-a-desk-32.png"))); // NOI18N
        jLabel51.setText("jLabel6");

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel3.setText("Departments");

        Std.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Std.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-department-50.png"))); // NOI18N
        jLabel52.setText("jLabel10");

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel4.setText("Students");

        Dep.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Dep.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-teacher-50.png"))); // NOI18N
        jLabel53.setText("jLabel8");

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel5.setText("Faculty");

        Fac.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Fac.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel54.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-pay-30.png"))); // NOI18N
        jLabel54.setText("jLabel9");

        jLabel7.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel7.setText("Finances");

        Fin.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Fin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8-cash-30.png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel8.setText("Salaries");

        Sal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Sal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Dep, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Std, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Fac, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Fin, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Sal, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Std, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Dep, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Fac, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Fin, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Sal, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 145, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/WhatsApp Image 2023-01-12 at 19.12.21.jpeg"))); // NOI18N
        jLabel9.setText("jLabel9");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 540, 540));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

    }//GEN-LAST:event_jButton12ActionPerformed

    private void Departments1Home4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Departments1Home4ActionPerformed

        Departments d1 = new Departments();
        dispose();
        d1.setVisible(true);
    }//GEN-LAST:event_Departments1Home4ActionPerformed

    private void Fees1Home5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Fees1Home5ActionPerformed

        Fees f1 = new Fees();
        dispose();
        f1.setVisible(true);
    }//GEN-LAST:event_Fees1Home5ActionPerformed

    private void Salary1Home6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salary1Home6ActionPerformed

        Salaries sal1 = new Salaries();
        dispose();
        sal1.setVisible(true);
    }//GEN-LAST:event_Salary1Home6ActionPerformed

    private void Faculty1Home7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Faculty1Home7ActionPerformed

        Faculty fac1 = new Faculty();
        dispose();
        fac1.setVisible(true);
    }//GEN-LAST:event_Faculty1Home7ActionPerformed

    private void Students1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Students1Home2ActionPerformed

        Student s1 = new Student();
        dispose();
        s1.setVisible(true);
    }//GEN-LAST:event_Students1Home2ActionPerformed

    private void Home1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Home1Home2ActionPerformed

        Home h1 = new Home();
        dispose();
        h1.setVisible(true);
    }//GEN-LAST:event_Home1Home2ActionPerformed

    private void Courses1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Courses1Home2ActionPerformed

        Course c1 = new Course();
        dispose();
        c1.setVisible(true);
    }//GEN-LAST:event_Courses1Home2ActionPerformed

    private void logout1Home2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout1Home2ActionPerformed

        Login log = new Login();
        dispose();
        log.setVisible(true);
    }//GEN-LAST:event_logout1Home2ActionPerformed

  


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Courses1;
    private javax.swing.JLabel Dep;
    private javax.swing.JButton Departments1;
    private javax.swing.JLabel Fac;
    private javax.swing.JButton Faculty1;
    private javax.swing.JButton Fees1;
    private javax.swing.JLabel Fin;
    private javax.swing.JButton Home1;
    private javax.swing.JLabel Sal;
    private javax.swing.JButton Salary1;
    private javax.swing.JLabel Std;
    private javax.swing.JButton Students1;
    private javax.swing.JButton jButton12;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JButton logout1;
    // End of variables declaration//GEN-END:variables

}
